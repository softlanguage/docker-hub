package crmls.ai.crmls_ai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@ComponentScan("crmls.ai.crmls_ai.controllers")
@SpringBootApplication
public class CrmlsAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrmlsAiApplication.class, args);
	}

}
